package com.example.awmrapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class Payment extends AppCompatActivity {

    Button PayBill;
    String cid,present,rs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        PayBill=(Button)findViewById(R.id.PayBill);
        Bundle b=getIntent().getExtras();
        if(b!=null)
        {
            present=b.getString("present");
            cid=b.getString("cid");
            rs=b.getString("rs");
            PayBill.setText("Rs. "+rs);
        }
        PayBill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //update firebase
                DatabaseReference reference= FirebaseDatabase.getInstance().getReference().child("User");
                Query query2=reference.orderByChild("customer_id").equalTo(cid);
                query2.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot snapshot : dataSnapshot.getChildren())
                        {
                            snapshot.getRef().child("prev_data").setValue(present);
                            Toast.makeText(getApplicationContext(),"value updated",Toast.LENGTH_SHORT).show();



                        }


                    }



                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });



                Intent i=new Intent(Payment.this,FinalPage.class);
                startActivity(i);
            }
        });
    }
}