package com.example.awmrapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ImageUpload extends AppCompatActivity {

    Button ter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_upload);
        ter=(Button)findViewById(R.id.terminate);
        ter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(ImageUpload.this,Login_page.class);
                startActivity(i);
            }
        });
        Toast.makeText(ImageUpload.this, "Pending For Admin Verification", Toast.LENGTH_SHORT).show();
    }
}