package com.example.awmrapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class Login_page extends AppCompatActivity {

    ImageView idIVLogo1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
        idIVLogo1=(ImageView) findViewById(R.id.idIVLogo);
        idIVLogo1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Login_page.this,MainActivity.class);
                startActivity(i);
            }
        });

    }
}